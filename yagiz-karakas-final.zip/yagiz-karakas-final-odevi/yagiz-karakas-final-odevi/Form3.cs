﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yagiz_karakas_final_odevi
{
    public partial class Form3 : Form
    {
        Form4 frm = new Form4();
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                frm.Show();
                Hide();

            }
        }
    }
}
