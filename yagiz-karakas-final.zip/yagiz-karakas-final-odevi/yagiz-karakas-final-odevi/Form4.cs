﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yagiz_karakas_final_odevi
{
    public partial class Form4 : Form
    {
        Form6 frm = new Form6();
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frm.Show();
            Hide();
        }
    }
}
